class IllegalMove(Exception):
    pass